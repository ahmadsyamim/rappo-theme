@include('Rappo.partials.meta')
@include('Rappo.partials.header')

<div class="container section">
  <div class="block">
    @yield('content')
  </div>
</div>

@include('Rappo.partials.footer')
